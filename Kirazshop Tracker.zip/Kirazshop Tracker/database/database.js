const Database = require("better-sqlite3");
const db = new Database("invites.sqlite");

// Tabla de invites extendida
db.prepare(`
  CREATE TABLE IF NOT EXISTS invites (
    guild_id TEXT,
    user_id TEXT,
    regular INTEGER DEFAULT 0,
    left INTEGER DEFAULT 0,
    fake INTEGER DEFAULT 0,
    bonus INTEGER DEFAULT 0,
    PRIMARY KEY (guild_id, user_id)
  )
`).run();

/////////////////////////////////////

module.exports = db;
db.prepare(`
  CREATE TABLE IF NOT EXISTS joins (
    guild_id TEXT,
    invited_id TEXT,
    inviter_id TEXT,
    PRIMARY KEY (guild_id, invited_id)
  )
`).run();

db.prepare(`
  CREATE TABLE IF NOT EXISTS vanity (
    guild_id TEXT PRIMARY KEY,
    uses INTEGER DEFAULT 0
  )
`).run();

db.prepare(`
  CREATE TABLE IF NOT EXISTS invite_channels (
    guild_id TEXT PRIMARY KEY,
    channel_id TEXT
  )
`).run();

db.prepare(`
  CREATE TABLE IF NOT EXISTS ping_channels (
    guild_id TEXT PRIMARY KEY,
    channel_id TEXT
  )
`).run();
