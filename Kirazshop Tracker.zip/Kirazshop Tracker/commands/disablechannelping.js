const { SlashCommandBuilder } = require("discord.js");
const db = require("../database/database");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("disablechannelping")
    .setDescription("Desactiva el ping automático de bienvenida"),

  async execute(interaction, { pingChannels }) {
    const guildId = interaction.guild.id;

    // Borrar de la base de datos
    db.prepare(`
      DELETE FROM ping_channels
      WHERE guild_id = ?
    `).run(guildId);

    // Borrar del Map en memoria
    pingChannels.delete(guildId);

    await interaction.reply({
      content: "El ping automático de bienvenida ha sido **desactivado**."
    });
  }
};
