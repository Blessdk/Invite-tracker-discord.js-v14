const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const db = require("../database/database");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("invites")
    .setDescription("Muestra tus invites o los de otro usuario")
    .addUserOption(option =>
      option
        .setName("usuario")
        .setDescription("Usuario a consultar")
        .setRequired(false)
    ),

  async execute(interaction) {
    const user =
      interaction.options.getUser("usuario") || interaction.user;

    const guildId = interaction.guild.id;

    const data = db.prepare(`
      SELECT regular, left, fake, bonus
      FROM invites
      WHERE guild_id = ? AND user_id = ?
    `).get(guildId, user.id) || {
      regular: 0,
      left: 0,
      fake: 0,
      bonus: 0
    };

    const total =
      data.regular - data.left - data.fake + data.bonus;

    const embed = new EmbedBuilder()
      .setColor(0x2b2d31)
      .setAuthor({
        name: user.tag,
        iconURL: user.displayAvatarURL()
      })
      .setDescription(
        `**Invites:** ${total}\n\n` +
        `➕ **Regulares:** ${data.regular}\n` +
        `❌ **Left:** ${data.left}\n` +
        `➖ **Fake:** ${data.fake}\n` +
        `⭐ **Bonus:** ${data.bonus}`
      );

    await interaction.reply({ embeds: [embed] });
  }
};
