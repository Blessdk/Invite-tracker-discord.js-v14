const {
  SlashCommandBuilder,
  PermissionsBitField
} = require("discord.js");
const db = require("../database/database");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("resetinvites")
    .setDescription("Resetea las invites de un usuario o del servidor")
    .addUserOption(option =>
      option
        .setName("usuario")
        .setDescription("Usuario al que resetear invites (opcional)")
        .setRequired(false)
    ),

  async execute(interaction) {
    if (
      !interaction.member.permissions.has(
        PermissionsBitField.Flags.ManageGuild
      )
    ) {
      return interaction.reply({
        content: "No tienes permisos para usar este comando.",
        ephemeral: true
      });
    }

    const guildId = interaction.guild.id;
    const targetUser = interaction.options.getUser("usuario");

    if (targetUser) {
      // Reset a un usuario
      db.prepare(`
        UPDATE invites
        SET regular = 0, left = 0, fake = 0, bonus = 0
        WHERE guild_id = ? AND user_id = ?
      `).run(guildId, targetUser.id);

      return interaction.reply({
        content: `Invites reseteadas para **${targetUser.tag}**.`,
        ephemeral: true
      });
    } else {
      // Reset global
      db.prepare(`
        UPDATE invites
        SET regular = 0, left = 0, fake = 0, bonus = 0
        WHERE guild_id = ?
      `).run(guildId);

      return interaction.reply({
        content: "Invites reseteadas para **todo el servidor**.",
         flags: 64 // MessageFlags.Ephemeral
      });
    }
  }
};
