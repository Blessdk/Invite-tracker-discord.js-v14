const {
  SlashCommandBuilder,
  PermissionsBitField
} = require("discord.js");
const db = require("../database/database");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("channelinvite")
    .setDescription("Configura el canal donde se enviarán los invites")
    .addChannelOption(option =>
      option
        .setName("canal")
        .setDescription("Canal de invites")
        .setRequired(true)
    ),

  async execute(interaction, { inviteChannels }) {
    if (
      !interaction.member.permissions.has(
        PermissionsBitField.Flags.ManageGuild
      )
    ) {
      return interaction.reply({
        content: "No tienes permisos para usar este comando."
      });
    }

    const channel = interaction.options.getChannel("canal");

    // Guardar en DB
    db.prepare(`
      INSERT OR REPLACE INTO invite_channels (guild_id, channel_id)
      VALUES (?, ?)
    `).run(interaction.guild.id, channel.id);

    // ACTUALIZAR MAP (CLAVE)
    inviteChannels.set(interaction.guild.id, channel.id);

    await interaction.reply({
      content: `Canal de invites configurado: ${channel}`
    });
  }
};
