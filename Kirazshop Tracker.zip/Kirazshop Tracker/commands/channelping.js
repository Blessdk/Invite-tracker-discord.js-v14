const { SlashCommandBuilder } = require("discord.js");
const db = require("../database/database");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("channelping")
    .setDescription("Configura el canal donde se pingeará a los nuevos usuarios")
    .addChannelOption(option =>
      option
        .setName("canal")
        .setDescription("Canal de bienvenida")
        .setRequired(true)
    ),

  async execute(interaction) {
    const channel = interaction.options.getChannel("canal");

    db.prepare(`
      INSERT OR REPLACE INTO ping_channels (guild_id, channel_id)
      VALUES (?, ?)
    `).run(interaction.guild.id, channel.id);

    await interaction.reply({
      content: `Canal de ping configurado: ${channel}`
    });
  }
};
