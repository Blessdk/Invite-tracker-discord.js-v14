const {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionsBitField
} = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("giveaways")
    .setDescription("Sistema de sorteos")
    .setDefaultMemberPermissions(
      PermissionsBitField.Flags.ManageMessages
    )

    // CREATE
    .addSubcommand(sub =>
      sub
        .setName("create")
        .setDescription("Crear un sorteo")
        .addStringOption(o =>
          o
            .setName("premio")
            .setDescription("Nombre del sorteo / premio")
            .setRequired(true)
        )
        .addStringOption(o =>
          o
            .setName("tiempo")
            .setDescription("Duración (10m, 1h, 1d)")
            .setRequired(true)
        )
        .addIntegerOption(o =>
          o
            .setName("ganadores")
            .setDescription("Cantidad de ganadores")
            .setRequired(true)
        )
    )

    // END
    .addSubcommand(sub =>
      sub
        .setName("end")
        .setDescription("Finalizar un sorteo")
        .addStringOption(o =>
          o
            .setName("message")
            .setDescription("ID del mensaje del sorteo")
            .setRequired(true)
        )
    )

    // REROLL
    .addSubcommand(sub =>
      sub
        .setName("reroll")
        .setDescription("Re-sortear ganadores")
        .addStringOption(o =>
          o
            .setName("message")
            .setDescription("ID del mensaje del sorteo")
            .setRequired(true)
        )
    ),

  async execute(interaction) {
    if (
      !interaction.member.permissions.has(
        PermissionsBitField.Flags.ManageMessages
      )
    ) {
      return interaction.reply({
        content: "No tienes permisos para usar este comando.",
        flags: 64
      });
    }

    const sub = interaction.options.getSubcommand();

    // ================= CREATE =================
    if (sub === "create") {
      const premio = interaction.options.getString("premio");
      const tiempoTexto = interaction.options.getString("tiempo");
      const ganadores = interaction.options.getInteger("ganadores");

      const match = tiempoTexto.match(/^(\d+)(s|m|h|d)$/);
      if (!match) {
        return interaction.reply({
          content: "Formato de tiempo inválido. Usa: 10m, 1h, 1d",
          flags: 64
        });
      }

      const ms =
        {
          s: 1000,
          m: 60000,
          h: 3600000,
          d: 86400000
        }[match[2]] * parseInt(match[1]);

      const endTimestamp = Math.floor((Date.now() + ms) / 1000);

      const embed = new EmbedBuilder()
        .setColor(0x5865f2)
        .setTitle("🎉 SORTEO 🎉")
        .setDescription(premio)
        .addFields(
          { name: "⏱ Termina", value: `<t:${endTimestamp}:R>` },
          {
            name: "👤 Organizado por",
            value: interaction.user.toString(),
            inline: true
          },
          {
            name: "🏆 Ganadores",
            value: ganadores.toString(),
            inline: true
          }
        )
        .setFooter({
          text: "Reacciona con 🎉 para participar"
        });

      const msg = await interaction.channel.send({
        embeds: [embed]
      });
      await msg.react("🎉");

      return interaction.reply({
        content: "Sorteo creado correctamente.",
        flags: 64
      });
    }

    // ================= END / REROLL =================
    const messageId = interaction.options.getString("message");
    const channel = interaction.channel;

    const message = await channel.messages
      .fetch(messageId)
      .catch(() => null);

    if (!message || !message.embeds.length) {
      return interaction.reply({
        content: "No se encontró un sorteo válido.",
        flags: 64
      });
    }

    const reaction = message.reactions.cache.get("🎉");
    if (!reaction) {
      return interaction.reply({
        content: "Ese mensaje no tiene reacciones de sorteo.",
        flags: 64
      });
    }

    const users = await reaction.users.fetch();
    const participantes = users.filter(u => !u.bot);

    if (!participantes.size) {
      return interaction.reply({
        content: "No hubo participantes en el sorteo.",
        flags: 64
      });
    }

    const embed = message.embeds[0];
    const giveawayName = embed.description || "Giveaway";

    let ganadores = 1;
    const field = embed.fields.find(f =>
      f.name.toLowerCase().includes("ganadores")
    );
    if (field) ganadores = parseInt(field.value) || 1;

    const list = [...participantes.values()];
    const winners = [];

    while (winners.length < ganadores && list.length) {
      const random = list.splice(
        Math.floor(Math.random() * list.length),
        1
      )[0];
      winners.push(random);
    }

    // MENSAJE FINAL (ESTILO DYNO, SIN BOTÓN)
    if (sub === "reroll") {
      await channel.send(
        `🔁 **Reroll winner:** ${winners
          .map(w => w.toString())
          .join(", ")}\n🎁 **Giveaway:** ${giveawayName}`
      );
    } else {
      await channel.send(
        `🎉 **Congratulations ${winners
          .map(w => w.toString())
          .join(", ")}, you won **${giveawayName}**!**`
      );
    }

    return interaction.reply({
      content: "Acción completada correctamente.",
      flags: 64
    });
  }
};