const { SlashCommandBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("both")
    .setDescription("El bot escribe un mensaje sin mostrar el comando")
    .addStringOption(option =>
      option
        .setName("mensaje")
        .setDescription("Texto a enviar")
        .setRequired(true)
    ),

  async execute(interaction) {
    const mensaje = interaction.options.getString("mensaje");

    await interaction.deferReply({ flags: 64 }); // ephemeral

    await interaction.channel.send(mensaje);

    await interaction.deleteReply();
  }
};
