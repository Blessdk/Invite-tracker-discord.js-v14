const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const db = require("../database/database");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("topinvites")
    .setDescription("Muestra el top de invites del servidor"),

  async execute(interaction) {
    const guildId = interaction.guild.id;

    const rows = db.prepare(`
      SELECT user_id,
      (regular - left - fake + bonus) AS total
      FROM invites
      WHERE guild_id = ?
      ORDER BY total DESC
      LIMIT 10
    `).all(guildId);

    if (!rows.length) {
      return interaction.reply("No hay invites registrados todavía.");
    }

    const description = rows
      .map((r, i) => `**${i + 1}.** <@${r.user_id}> — ${r.total}`)
      .join("\n");

    const embed = new EmbedBuilder()
      .setTitle("🏆 Top Invites")
      .setColor(0x2b2d31)
      .setDescription(description);

    await interaction.reply({ embeds: [embed] });
  }
};
