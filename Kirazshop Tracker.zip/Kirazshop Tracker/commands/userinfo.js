const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("userinfo")
    .setDescription("Muestra información de un usuario")
    .addUserOption(option =>
      option
        .setName("usuario")
        .setDescription("Usuario a consultar")
        .setRequired(false)
    ),

  async execute(interaction) {
    const user =
      interaction.options.getUser("usuario") || interaction.user;

    const embed = new EmbedBuilder()
      .setColor(0x2b2d31)
      .setAuthor({
        name: user.tag,
        iconURL: user.displayAvatarURL()
      })
      .addFields(
        { name: "ID", value: user.id, inline: true },
        {
          name: "Cuenta creada",
          value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`,
          inline: true
        }
      );

    await interaction.reply({ embeds: [embed] });
  }
};
