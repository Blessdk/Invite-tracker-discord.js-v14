const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("help")
    .setDescription("Muestra todos los comandos del bot"),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setTitle("📘 Ayuda")
      .setColor(0x2b2d31)
      .setDescription("Comandos disponibles:")
      .addFields(
        {
          name: "📊 Invites",
          value:
            "`/invites` → Ver invites\n" +
            "`/topinvites` → Top del servidor",
          inline: false
        },
        {
          name: "🛠️ Utilidad",
          value:
            "`/both` → El bot escribe un mensaje",
          inline: false
        },
        {
          name: "👤 Usuario",
          value:
            "`/userinfo` → Información de un usuario",
          inline: false
        }
      );

    await interaction.reply({ embeds: [embed] });
  }
};
