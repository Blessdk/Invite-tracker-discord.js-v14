require("dotenv").config();

const {
  Client,
  GatewayIntentBits,
  Partials,
  REST,
  Routes
} = require("discord.js");

const fs = require("fs");
const path = require("path");
const db = require("./database/database");

/* =========================
   CLIENTE
========================= */
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers
  ],
  partials: [Partials.GuildMember]
});

/* =========================
   MAPS EN MEMORIA
========================= */
const inviteCache = new Map();        // guildId -> invites[]
const inviteChannels = new Map();     // guildId -> channelId
const vanityCache = new Map();        // guildId -> vanity uses
const pingChannels = new Map();        // guildId -> ping uses

/* =========================
   COMANDOS
========================= */
client.commands = new Map();

/* =========================
   READY
========================= */
client.once("ready", async () => {
  console.log(`Bot conectado como ${client.user.tag}`);

client.user.setPresence({
  status: "online",
  activities: [
    {
      name: ".gg/kirazshop",
      type: 0 // Playing
    }
  ]
});

  // Cachear invites iniciales
  for (const guild of client.guilds.cache.values()) {
    try {
      const invites = await guild.invites.fetch();
      inviteCache.set(
        guild.id,
        invites.map(inv => ({ code: inv.code, uses: inv.uses }))
      );

      if (guild.features.includes("VANITY_URL")) {
        const vanity = await guild.fetchVanityData();
        vanityCache.set(guild.id, vanity.uses);
      }
    } catch (err) {
  console.error(err);

  if (!interaction.replied && !interaction.deferred) {
    await interaction.reply({
      content: "Ocurrió un error ejecutando el comando.",
      flags: 64 
    });
  }
}


  }

const pingRows = db.prepare(`
  SELECT guild_id, channel_id FROM ping_channels
`).all();

for (const row of pingRows) {
  pingChannels.set(row.guild_id, row.channel_id);
}

  // Cargar canales desde DB
  const rows = db.prepare(`
    SELECT guild_id, channel_id FROM invite_channels
  `).all();

  for (const row of rows) {
    inviteChannels.set(row.guild_id, row.channel_id);
  }

  // Cargar comandos
  const commandsPath = path.join(__dirname, "commands");
  const commandFiles = fs
    .readdirSync(commandsPath)
    .filter(file => file.endsWith(".js"));

  const commandsJSON = [];

  for (const file of commandFiles) {
    const command = require(path.join(commandsPath, file));
    client.commands.set(command.data.name, command);
    commandsJSON.push(command.data.toJSON());
  }

  const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);

  await rest.put(
    Routes.applicationCommands(client.user.id),
    { body: commandsJSON }
  );

  console.log("Comandos slash registrados correctamente");
});

/* =========================
   INTERACTIONS
========================= */
client.on("interactionCreate", async interaction => {
  if (!interaction.isChatInputCommand()) return;

  const command = client.commands.get(interaction.commandName);
  if (!command) return;

  try {
    await command.execute(interaction, {
      inviteChannels,
      pingChannels
    });
  } catch (err) {
    console.error(err);
    // ❌ NO RESPONDAS NUNCA AQUÍ
  }
});


/* =========================
   INVITE CREATE
========================= */
client.on("inviteCreate", invite => {
  const invites = inviteCache.get(invite.guild.id) || [];
  invites.push({ code: invite.code, uses: invite.uses });
  inviteCache.set(invite.guild.id, invites);
});

/* =========================
   GUILD MEMBER ADD
========================= */
client.on("guildMemberAdd", async member => {
  const guildId = member.guild.id;

// ===== PING DE BIENVENIDA (1 SEGUNDO) =====
const pingChannelId = pingChannels.get(member.guild.id);
if (pingChannelId) {
  const pingChannel = member.guild.channels.cache.get(pingChannelId);
  if (pingChannel) {
    try {
      const msg = await pingChannel.send(`${member}`);
      setTimeout(() => {
        msg.delete().catch(() => {});
      }, 1000);
    } catch (e) {
      console.log("No se pudo enviar el ping:", e.message);
    }
  }
}
  
  // ===== INVITES =====
  const cachedInvites = inviteCache.get(guildId);
  const newInvites = await member.guild.invites.fetch();

  const usedInvite = newInvites.find(inv => {
    const old = cachedInvites?.find(i => i.code === inv.code);
    return old && inv.uses > old.uses;
  });



  // ===== VANITY URL =====
  if (!usedInvite && member.guild.features.includes("VANITY_URL")) {
    const vanity = await member.guild.fetchVanityData();
    const oldUses = vanityCache.get(guildId) || 0;

    if (vanity.uses > oldUses) {
      vanityCache.set(guildId, vanity.uses);

      db.prepare(`
        INSERT OR IGNORE INTO vanity (guild_id, uses)
        VALUES (?, 0)
      `).run(guildId);

      db.prepare(`
        UPDATE vanity SET uses = uses + 1
        WHERE guild_id = ?
      `).run(guildId);

      const channelId = inviteChannels.get(guildId);
      const channel = channelId
        ? member.guild.channels.cache.get(channelId)
        : null;

      if (channel) {
        channel.send(
          `${member} joined using the **server vanity URL**`
        );
      }

      inviteCache.set(
        guildId,
        newInvites.map(inv => ({ code: inv.code, uses: inv.uses }))
      );
      return;
    }
  }

  // ===== SIN INVITE =====
  if (!usedInvite || !usedInvite.inviter) {
    inviteCache.set(
      guildId,
      newInvites.map(inv => ({ code: inv.code, uses: inv.uses }))
    );
    return;
  }

  // ===== ANTI DUPLICADO (CRÍTICO) =====
  const alreadyJoined = db.prepare(`
    SELECT 1 FROM joins
    WHERE guild_id = ? AND invited_id = ?
  `).get(guildId, member.id);

  if (alreadyJoined) {
    inviteCache.set(
      guildId,
      newInvites.map(inv => ({ code: inv.code, uses: inv.uses }))
    );
    return;
  }

  // ===== INVITE NORMAL =====
  const inviterId = usedInvite.inviter.id;

  db.prepare(`
    INSERT OR IGNORE INTO invites (guild_id, user_id)
    VALUES (?, ?)
  `).run(guildId, inviterId);

  // ===== FAKE DETECTION =====
  const accountAgeMs = Date.now() - member.user.createdAt.getTime();
  const sevenDaysMs = 7 * 24 * 60 * 60 * 1000;
  const isFake = member.user.bot || accountAgeMs < sevenDaysMs;

  if (isFake) {
    db.prepare(`
      UPDATE invites SET fake = fake + 1
      WHERE guild_id = ? AND user_id = ?
    `).run(guildId, inviterId);
  } else {
    db.prepare(`
      UPDATE invites SET regular = regular + 1
      WHERE guild_id = ? AND user_id = ?
    `).run(guildId, inviterId);
  }

  // ===== GUARDAR JOIN (LEFT) =====
  db.prepare(`
    INSERT OR REPLACE INTO joins (guild_id, invited_id, inviter_id)
    VALUES (?, ?, ?)
  `).run(guildId, member.id, inviterId);

  // ===== LEER STATS ACTUALIZADAS =====
  const stats = db.prepare(`
    SELECT regular, left, fake, bonus
    FROM invites
    WHERE guild_id = ? AND user_id = ?
  `).get(guildId, inviterId);

  const totalInvites =
    (stats?.regular ?? 0) -
    (stats?.left ?? 0) -
    (stats?.fake ?? 0) +
    (stats?.bonus ?? 0);

  // ===== MENSAJE =====
  const channelId = inviteChannels.get(guildId);
  const channel = channelId
    ? member.guild.channels.cache.get(channelId)
    : null;

  if (channel) {
    channel.send(
      `${member} has been invited by ${usedInvite.inviter.tag} (*${totalInvites} invites*)`
    );
  }

  // ===== ACTUALIZAR CACHE =====
  inviteCache.set(
    guildId,
    newInvites.map(inv => ({ code: inv.code, uses: inv.uses }))
  );
});


/* =========================
   GUILD MEMBER REMOVE (LEFT)
========================= */
client.on("guildMemberRemove", member => {
  const guildId = member.guild.id;

  const join = db.prepare(`
    SELECT inviter_id FROM joins
    WHERE guild_id = ? AND invited_id = ?
  `).get(guildId, member.id);

  if (!join) return;

  db.prepare(`
    UPDATE invites SET left = left + 1
    WHERE guild_id = ? AND user_id = ?
  `).run(guildId, join.inviter_id);

  db.prepare(`
    DELETE FROM joins
    WHERE guild_id = ? AND invited_id = ?
  `).run(guildId, member.id);
});

/* =========================
   LOGIN
========================= */
client.login(process.env.DISCORD_TOKEN);

